package com.example.screenocrmatcher

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.view.*
import android.widget.*
import androidx.core.app.NotificationCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import org.json.JSONArray
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.min

class ScreenCaptureService : Service() {

    companion object {
        const val ACTION_START = "com.example.screenocrmatcher.START"
        const val ACTION_STOP = "com.example.screenocrmatcher.STOP"
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_RESULT_DATA = "result_data"

        private const val CHANNEL_ID = "screen_ocr_matcher_channel"
        private const val NOTIFICATION_ID = 1001
    }

    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null

    private lateinit var windowManager: WindowManager
    private var overlayView: View? = null
    private var overlayTitle: TextView? = null
    private var overlayMain: TextView? = null
    private var overlaySub: TextView? = null

    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    private val busy = AtomicBoolean(false)
    private var lastProcessedAt = 0L

    private lateinit var headwords: List<String>

    override fun onBind(intent: Intent?) = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        createNotificationChannel()
        headwords = loadHeadwords()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopCapture()
                stopSelf()
                return START_NOT_STICKY
            }

            ACTION_START -> {
                startForegroundCompat()

                val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
                @Suppress("DEPRECATION")
                val resultData = if (Build.VERSION.SDK_INT >= 33) {
                    intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
                } else {
                    intent.getParcelableExtra(EXTRA_RESULT_DATA)
                }

                if (resultCode == Activity.RESULT_OK && resultData != null) {
                    startCapture(resultCode, resultData)
                } else {
                    stopSelf()
                }
            }
        }
        return START_NOT_STICKY
    }

    private fun loadHeadwords(): List<String> {
        val raw = assets.open("headwords.json").bufferedReader().use { it.readText() }
        val arr = JSONArray(raw)
        return List(arr.length()) { arr.getString(it) }
    }

    private fun startForegroundCompat() {
        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentTitle("화면 OCR 자동 인식")
            .setContentText("200개 표제어와 화면 텍스트를 자동 대조 중")
            .setOngoing(true)
            .build()

        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun startCapture(resultCode: Int, data: Intent) {
        if (projection != null) return

        showOverlay()

        val pm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = pm.getMediaProjection(resultCode, data)

        projection?.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                stopCapture()
                stopSelf()
            }
        }, Handler(Looper.getMainLooper()))

        val width: Int
        val height: Int
        val dpi = resources.displayMetrics.densityDpi

        if (Build.VERSION.SDK_INT >= 30) {
            val bounds = windowManager.currentWindowMetrics.bounds
            width = bounds.width()
            height = bounds.height()
        } else {
            @Suppress("DEPRECATION")
            val dm = resources.displayMetrics
            width = dm.widthPixels
            height = dm.heightPixels
        }

        imageReader = ImageReader.newInstance(
            width,
            height,
            PixelFormat.RGBA_8888,
            2
        )

        imageReader?.setOnImageAvailableListener({ reader ->
            val now = System.currentTimeMillis()

            if (now - lastProcessedAt < 650L || busy.get()) {
                reader.acquireLatestImage()?.close()
                return@setOnImageAvailableListener
            }

            val image = reader.acquireLatestImage() ?: return@setOnImageAvailableListener
            lastProcessedAt = now
            busy.set(true)

            try {
                val bitmap = imageToBitmap(image)
                if (bitmap != null) {
                    runOcr(bitmap)
                } else {
                    busy.set(false)
                }
            } finally {
                image.close()
            }
        }, Handler(Looper.getMainLooper()))

        virtualDisplay = projection?.createVirtualDisplay(
            "ScreenOcrMatcher",
            width,
            height,
            dpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader?.surface,
            null,
            null
        )
    }

    private fun imageToBitmap(image: Image): Bitmap? {
        val plane = image.planes.firstOrNull() ?: return null
        val buffer = plane.buffer
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        val rowPadding = rowStride - pixelStride * image.width

        val bitmap = Bitmap.createBitmap(
            image.width + rowPadding / pixelStride,
            image.height,
            Bitmap.Config.ARGB_8888
        )

        buffer.rewind()
        bitmap.copyPixelsFromBuffer(buffer)

        val cropped = Bitmap.createBitmap(bitmap, 0, 0, image.width, image.height)
        if (cropped !== bitmap) bitmap.recycle()
        return cropped
    }

    private fun runOcr(bitmap: Bitmap) {
        recognizer.process(InputImage.fromBitmap(bitmap, 0))
            .addOnSuccessListener { result ->
                val text = result.text.orEmpty()

                val matches = findHeadwordMatches(text)
                val korean = extractKoreanSnippet(text)

                if (matches.isNotEmpty()) {
                    overlayTitle?.text = "표제어 자동 인식"
                    overlayMain?.text = matches.joinToString("\n")
                    overlaySub?.text =
                        if (korean.isNotBlank()) "화면 한글: $korean"
                        else "화면에서 200개 목록과 일치한 표제어"
                } else {
                    overlayTitle?.text = "OCR 인식"
                    overlayMain?.text =
                        if (korean.isNotBlank()) korean
                        else firstUsefulLine(text).ifBlank { "인식 대기 중…" }
                    overlaySub?.text = "표제어 일치 없음"
                }
            }
            .addOnFailureListener {
                overlayTitle?.text = "OCR 오류"
                overlayMain?.text = it.message ?: "알 수 없는 오류"
                overlaySub?.text = ""
            }
            .addOnCompleteListener {
                bitmap.recycle()
                busy.set(false)
            }
    }

    private fun findHeadwordMatches(raw: String): List<String> {
        val normalizedScreen = normalize(raw)
        val rawTokens = normalizedScreen
            .split(Regex("[^a-zA-Z]+"))
            .map { it.lowercase(Locale.US).trim() }
            .filter { it.length >= 2 }

        val scored = mutableListOf<Pair<String, Int>>()

        for (word in headwords) {
            val nw = normalize(word)

            // Phrase/exact substring match.
            if (normalizedScreen.contains(nw)) {
                scored += word to 100
                continue
            }

            // Single-word fuzzy OCR correction.
            if (!nw.contains(" ")) {
                var best = 999
                for (token in rawTokens) {
                    if (kotlin.math.abs(token.length - nw.length) > 2) continue
                    best = min(best, levenshtein(token, nw))
                }

                val threshold = when {
                    nw.length >= 9 -> 2
                    nw.length >= 5 -> 1
                    else -> 0
                }

                if (best <= threshold) {
                    scored += word to (80 - best * 10)
                }
            }
        }

        return scored
            .sortedByDescending { it.second }
            .map { it.first }
            .distinct()
            .take(3)
    }

    private fun normalize(s: String): String =
        s.lowercase(Locale.US)
            .replace(Regex("\\s+"), " ")
            .trim()

    private fun extractKoreanSnippet(raw: String): String {
        val lines = raw.lines()
            .map { it.trim() }
            .filter { line -> line.any { ch -> ch in '\uAC00'..'\uD7A3' } }
            .filter { it.length >= 2 }

        return lines.take(2).joinToString(" / ").take(110)
    }

    private fun firstUsefulLine(raw: String): String =
        raw.lines()
            .map { it.trim() }
            .firstOrNull { it.length >= 2 }
            .orEmpty()
            .take(100)

    private fun levenshtein(a: String, b: String): Int {
        if (a == b) return 0
        if (a.isEmpty()) return b.length
        if (b.isEmpty()) return a.length

        var prev = IntArray(b.length + 1) { it }
        var cur = IntArray(b.length + 1)

        for (i in a.indices) {
            cur[0] = i + 1
            for (j in b.indices) {
                val cost = if (a[i] == b[j]) 0 else 1
                cur[j + 1] = minOf(
                    cur[j] + 1,
                    prev[j + 1] + 1,
                    prev[j] + cost
                )
            }
            val tmp = prev
            prev = cur
            cur = tmp
        }
        return prev[b.length]
    }

    private fun showOverlay() {
        if (overlayView != null) return

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(8), dp(10), dp(9))
            setBackgroundColor(0xEFFFFFFF.toInt())
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        overlayTitle = TextView(this).apply {
            text = "자동 OCR"
            textSize = 12f
            setTextColor(0xFF666666.toInt())
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        }

        val close = TextView(this).apply {
            text = "  ×  "
            textSize = 20f
            setTextColor(0xFF333333.toInt())
            setOnClickListener {
                stopCapture()
                stopSelf()
            }
        }

        header.addView(
            overlayTitle,
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        )
        header.addView(close)

        overlayMain = TextView(this).apply {
            text = "인식 대기 중…"
            textSize = 19f
            setTextColor(0xFF111111.toInt())
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(0, dp(5), 0, 0)
            maxLines = 4
        }

        overlaySub = TextView(this).apply {
            text = ""
            textSize = 11f
            setTextColor(0xFF777777.toInt())
            setPadding(0, dp(4), 0, 0)
            maxLines = 3
        }

        root.addView(header)
        root.addView(overlayMain)
        root.addView(overlaySub)

        val params = WindowManager.LayoutParams(
            dp(225),
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.END
            x = dp(8)
            y = dp(150)
            alpha = 0.94f
        }

        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0

        header.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.rawX
                    downY = event.rawY
                    startX = params.x
                    startY = params.y
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = startX - (event.rawX - downX).toInt()
                    params.y = startY + (event.rawY - downY).toInt()
                    overlayView?.let { windowManager.updateViewLayout(it, params) }
                    true
                }
                else -> false
            }
        }

        overlayView = root
        windowManager.addView(root, params)
    }

    private fun stopCapture() {
        try { virtualDisplay?.release() } catch (_: Exception) {}
        virtualDisplay = null

        try { imageReader?.close() } catch (_: Exception) {}
        imageReader = null

        try { projection?.stop() } catch (_: Exception) {}
        projection = null

        overlayView?.let {
            try { windowManager.removeView(it) } catch (_: Exception) {}
        }
        overlayView = null
        overlayTitle = null
        overlayMain = null
        overlaySub = null
        busy.set(false)
    }

    private fun dp(v: Int): Int =
        (v * resources.displayMetrics.density).toInt()

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "화면 OCR 자동 인식",
                NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java)
                .createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        stopCapture()
        recognizer.close()
        super.onDestroy()
    }
}
