# LiveVocabOverlayV1

개인 학습용 Android 화면 OCR + 플로팅 단어 검색기입니다.

## 동작
1. 앱에서 `다른 앱 위에 표시` 권한 허용
2. 알림 권한 허용(Android 13+)
3. `OCR 오버레이 시작` → Android 화면 공유 시스템 창에서 허용
4. 화면 가장자리에 플로팅 창이 나타남
5. OCR 텍스트는 약 1.1초 간격으로 갱신
6. `학습 검색`을 눌렀을 때만 현재 OCR 텍스트와 `assets/vocab.json`을 대조해 최대 3개 후보 표시
7. `일시정지/재개`, `닫기` 지원. 제목 줄을 드래그해 이동 가능

## 권한
- SYSTEM_ALERT_WINDOW: 플로팅 창
- FOREGROUND_SERVICE / FOREGROUND_SERVICE_MEDIA_PROJECTION: 화면 캡처 서비스
- POST_NOTIFICATIONS: 포그라운드 서비스 알림(Android 13+)

## 참고
- 화면 회전 후 캡처 크기가 맞지 않으면 닫고 다시 시작하세요.
- 오버레이 자체에는 FLAG_SECURE를 적용해 OCR 재인식 루프를 줄였습니다.
- 평가/시험 등 참고도구 사용이 금지된 상황에서는 사용하지 마세요.
