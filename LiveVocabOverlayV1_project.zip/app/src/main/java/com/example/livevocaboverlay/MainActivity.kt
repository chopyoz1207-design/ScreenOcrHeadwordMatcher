package com.example.livevocaboverlay

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {

    private lateinit var projectionManager: MediaProjectionManager
    private lateinit var status: TextView

    private val overlayPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            updateStatus()
        }

    private val notificationPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) {
            updateStatus()
        }

    private val projectionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode != Activity.RESULT_OK || result.data == null) {
                status.text = "화면 공유가 취소되었습니다."
                return@registerForActivityResult
            }

            val serviceIntent = Intent(this, CaptureOverlayService::class.java).apply {
                putExtra(CaptureOverlayService.EXTRA_RESULT_CODE, result.resultCode)
                putExtra(CaptureOverlayService.EXTRA_RESULT_DATA, result.data)
            }
            ContextCompat.startForegroundService(this, serviceIntent)
            status.text = "OCR 오버레이를 시작했습니다. 화면 가장자리의 팝업을 확인하세요."
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        projectionManager = getSystemService(MediaProjectionManager::class.java)
        setContentView(buildUi())
        updateStatus()
    }

    override fun onResume() {
        super.onResume()
        if (::status.isInitialized) updateStatus()
    }

    private fun buildUi(): LinearLayout {
        val pad = dp(22)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
            setBackgroundColor(Color.rgb(247, 248, 250))
            gravity = Gravity.CENTER_HORIZONTAL
        }

        val title = TextView(this).apply {
            text = "Vocab OCR Overlay"
            textSize = 28f
            setTextColor(Color.BLACK)
        }
        val desc = TextView(this).apply {
            text = "개인 학습용 화면 OCR + 플로팅 검색기\nOCR 결과는 자동으로 정답으로 변환하지 않고, 팝업의 ‘학습 검색’ 버튼을 눌렀을 때 단어장에서 조회합니다."
            textSize = 15f
            setTextColor(Color.DKGRAY)
            setPadding(0, dp(12), 0, dp(18))
        }

        fun button(label: String, action: () -> Unit) = Button(this).apply {
            text = label
            textSize = 16f
            setOnClickListener { action() }
        }

        val overlayButton = button("1. 다른 앱 위에 표시 권한 허용") { requestOverlayPermission() }
        val startButton = button("2. OCR 오버레이 시작") { startCaptureFlow() }
        val stopButton = button("오버레이 완전히 중지") {
            stopService(Intent(this, CaptureOverlayService::class.java))
            status.text = "오버레이 서비스를 중지했습니다."
        }

        status = TextView(this).apply {
            textSize = 14f
            setTextColor(Color.rgb(70, 70, 70))
            setPadding(0, dp(20), 0, 0)
        }

        root.addView(title, matchWrap())
        root.addView(desc, matchWrap())
        root.addView(overlayButton, matchWrap())
        root.addView(startButton, matchWrap(top = 10))
        root.addView(stopButton, matchWrap(top = 10))
        root.addView(status, matchWrap())
        return root
    }

    private fun requestOverlayPermission() {
        if (Settings.canDrawOverlays(this)) {
            status.text = "오버레이 권한이 이미 허용되어 있습니다."
            return
        }
        overlayPermissionLauncher.launch(
            Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
        )
    }

    private fun startCaptureFlow() {
        if (!Settings.canDrawOverlays(this)) {
            status.text = "먼저 ‘다른 앱 위에 표시’ 권한을 허용하세요."
            requestOverlayPermission()
            return
        }

        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            status.text = "화면 캡처 서비스 알림을 위해 알림 권한을 먼저 요청합니다. 허용 후 시작 버튼을 다시 눌러주세요."
            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            return
        }

        projectionLauncher.launch(projectionManager.createScreenCaptureIntent())
    }

    private fun updateStatus() {
        val overlay = if (Settings.canDrawOverlays(this)) "허용됨" else "미허용"
        val notifications = if (Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        ) "허용됨" else "미허용"
        status.text = "오버레이 권한: $overlay\n알림 권한: $notifications\n\n시작 시 Android의 화면 공유 확인 창이 한 번 표시됩니다."
    }

    private fun matchWrap(top: Int = 0) =
        LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
            topMargin = dp(top)
        }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
