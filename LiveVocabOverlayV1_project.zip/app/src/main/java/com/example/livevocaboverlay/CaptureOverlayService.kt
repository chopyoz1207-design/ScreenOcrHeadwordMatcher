package com.example.livevocaboverlay

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.view.*
import android.widget.*
import androidx.core.app.NotificationCompat
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.TextRecognizer
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlin.math.min

class CaptureOverlayService : Service() {

    companion object {
        const val EXTRA_RESULT_CODE = "resultCode"
        const val EXTRA_RESULT_DATA = "resultData"
        private const val CHANNEL_ID = "screen_ocr"
        private const val NOTIFICATION_ID = 1001
        private const val OCR_INTERVAL_MS = 1100L
    }

    private lateinit var repo: VocabRepository
    private lateinit var latinRecognizer: TextRecognizer
    private lateinit var koreanRecognizer: TextRecognizer
    private lateinit var captureThread: HandlerThread
    private lateinit var captureHandler: Handler
    private val mainHandler = Handler(Looper.getMainLooper())

    private var mediaProjection: MediaProjection? = null
    private var projectionCallback: MediaProjection.Callback? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null

    private var overlayView: View? = null
    private var overlayParams: WindowManager.LayoutParams? = null
    private lateinit var windowManager: WindowManager
    private var recognizedTextView: TextView? = null
    private var resultTextView: TextView? = null
    private var pauseButton: Button? = null

    @Volatile private var paused = false
    @Volatile private var busy = false
    @Volatile private var lastOcrAt = 0L
    @Volatile private var lastOcrText = ""

    override fun onCreate() {
        super.onCreate()
        repo = VocabRepository(this)
        latinRecognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        koreanRecognizer = TextRecognition.getClient(KoreanTextRecognizerOptions.Builder().build())
        captureThread = HandlerThread("screen-ocr-capture").apply { start() }
        captureHandler = Handler(captureThread.looper)
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startProjectionForeground()
        showOverlayIfNeeded()

        val startIntent = intent ?: return START_NOT_STICKY
        val resultCode = startIntent.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
        val resultData: Intent? = if (Build.VERSION.SDK_INT >= 33) {
            startIntent.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
        } else {
            @Suppress("DEPRECATION")
            startIntent.getParcelableExtra(EXTRA_RESULT_DATA)
        }

        if (resultCode != Activity.RESULT_OK || resultData == null) {
            recognizedTextView?.text = "화면 공유 권한 정보가 없습니다."
            stopSelf()
            return START_NOT_STICKY
        }

        try {
            startProjection(resultCode, resultData)
        } catch (t: Throwable) {
            recognizedTextView?.text = "화면 캡처 시작 실패: ${t.javaClass.simpleName}"
            resultTextView?.text = t.message ?: "알 수 없는 오류"
        }
        return START_NOT_STICKY
    }

    override fun onBind(intent: Intent?) = null

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "화면 OCR",
                NotificationManager.IMPORTANCE_LOW
            ).apply { description = "화면 텍스트 인식 서비스" }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun startProjectionForeground() {
        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_ocr)
            .setContentTitle("화면 OCR 실행 중")
            .setContentText("개인 학습용 OCR 오버레이가 실행 중입니다.")
            .setOngoing(true)
            .build()

        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun startProjection(resultCode: Int, resultData: Intent) {
        cleanupCapture(stopProjection = true)

        val manager = getSystemService(MediaProjectionManager::class.java)
        val projection = manager.getMediaProjection(resultCode, resultData)
        mediaProjection = projection

        val callback = object : MediaProjection.Callback() {
            override fun onStop() {
                cleanupCapture(stopProjection = false)
                mainHandler.post {
                    recognizedTextView?.text = "화면 공유가 종료되었습니다."
                    resultTextView?.text = "앱에서 다시 시작할 수 있습니다."
                }
            }
        }
        projectionCallback = callback
        projection.registerCallback(callback, mainHandler)

        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val realWidth: Int
        val realHeight: Int
        val densityDpi = resources.displayMetrics.densityDpi

        if (Build.VERSION.SDK_INT >= 30) {
            val bounds = wm.maximumWindowMetrics.bounds
            realWidth = bounds.width()
            realHeight = bounds.height()
        } else {
            val dm = android.util.DisplayMetrics()
            @Suppress("DEPRECATION")
            wm.defaultDisplay.getRealMetrics(dm)
            realWidth = dm.widthPixels
            realHeight = dm.heightPixels
        }

        val scale = min(1f, 1080f / realWidth.toFloat())
        val captureWidth = (realWidth * scale).toInt().coerceAtLeast(360)
        val captureHeight = (realHeight * scale).toInt().coerceAtLeast(640)

        val reader = ImageReader.newInstance(
            captureWidth,
            captureHeight,
            PixelFormat.RGBA_8888,
            2
        )
        imageReader = reader

        virtualDisplay = projection.createVirtualDisplay(
            "VocabOcrCapture",
            captureWidth,
            captureHeight,
            densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader.surface,
            null,
            captureHandler
        )

        reader.setOnImageAvailableListener({ r -> onImageAvailable(r) }, captureHandler)
        recognizedTextView?.text = "OCR 시작됨 · 화면 텍스트를 읽는 중..."
        resultTextView?.text = "‘학습 검색’을 누르면 현재 OCR 텍스트와 200단어장을 대조합니다."
    }

    private fun onImageAvailable(reader: ImageReader) {
        val image = reader.acquireLatestImage() ?: return
        val now = SystemClock.elapsedRealtime()
        if (paused || busy || now - lastOcrAt < OCR_INTERVAL_MS) {
            image.close()
            return
        }

        busy = true
        lastOcrAt = now
        try {
            val bitmap = imageToBitmap(image)
            image.close()
            runOcr(bitmap)
        } catch (t: Throwable) {
            try { image.close() } catch (_: Throwable) {}
            busy = false
            mainHandler.post { recognizedTextView?.text = "OCR 프레임 처리 오류: ${t.javaClass.simpleName}" }
        }
    }

    private fun runOcr(bitmap: Bitmap) {
        val input = InputImage.fromBitmap(bitmap, 0)
        val latinTask = latinRecognizer.process(input)
        val koreanTask = koreanRecognizer.process(input)

        Tasks.whenAllComplete(latinTask, koreanTask).addOnCompleteListener {
            val lines = mutableListOf<String>()
            if (latinTask.isSuccessful) lines += latinTask.result.text.lines()
            if (koreanTask.isSuccessful) lines += koreanTask.result.text.lines()

            val merged = lines
                .map { it.trim() }
                .filter { it.isNotBlank() }
                .distinct()
                .joinToString("\n")

            lastOcrText = merged
            mainHandler.post {
                recognizedTextView?.text = if (merged.isBlank()) {
                    "인식된 텍스트 없음"
                } else {
                    "OCR:\n" + merged.take(360)
                }
                resultTextView?.text = "학습 검색 대기 중"
            }
            try { bitmap.recycle() } catch (_: Throwable) {}
            busy = false
        }
    }

    private fun imageToBitmap(image: Image): Bitmap {
        val plane = image.planes[0]
        val buffer = plane.buffer
        buffer.rewind()
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        val rowPadding = rowStride - pixelStride * image.width
        val paddedWidth = image.width + rowPadding / pixelStride

        val padded = Bitmap.createBitmap(paddedWidth, image.height, Bitmap.Config.ARGB_8888)
        padded.copyPixelsFromBuffer(buffer)
        if (paddedWidth == image.width) return padded

        val cropped = Bitmap.createBitmap(padded, 0, 0, image.width, image.height)
        padded.recycle()
        return cropped
    }

    private fun showOverlayIfNeeded() {
        if (overlayView != null) return
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(10), dp(12), dp(10))
            background = GradientDrawable().apply {
                cornerRadius = dp(14).toFloat()
                setColor(Color.argb(238, 32, 33, 36))
                setStroke(dp(1), Color.argb(180, 255, 255, 255))
            }
        }

        val dragHandle = TextView(this).apply {
            text = "OCR 단어 검색  ⋮⋮"
            textSize = 14f
            setTextColor(Color.WHITE)
            setPadding(dp(4), dp(2), dp(4), dp(8))
        }
        val recognized = TextView(this).apply {
            text = "OCR 준비 중..."
            textSize = 13f
            setTextColor(Color.WHITE)
            maxLines = 8
        }
        val result = TextView(this).apply {
            text = ""
            textSize = 13f
            setTextColor(Color.rgb(190, 245, 139))
            setPadding(0, dp(8), 0, dp(6))
            maxLines = 10
        }
        val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val pause = smallButton("일시정지") {
            paused = !paused
            pauseButton?.text = if (paused) "재개" else "일시정지"
            resultTextView?.text = if (paused) "OCR 일시정지됨" else "OCR 재개됨"
        }
        val lookup = smallButton("학습 검색") { showLookupResult() }
        val close = smallButton("닫기") { stopSelf() }

        buttons.addView(pause, weightParam())
        buttons.addView(lookup, weightParam())
        buttons.addView(close, weightParam())

        root.addView(dragHandle, matchWrap())
        root.addView(recognized, matchWrap())
        root.addView(result, matchWrap())
        root.addView(buttons, matchWrap())

        recognizedTextView = recognized
        resultTextView = result
        pauseButton = pause

        val params = WindowManager.LayoutParams(
            dp(285),
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_SECURE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = resources.displayMetrics.widthPixels - dp(300)
            y = dp(150)
        }
        overlayParams = params
        windowManager.addView(root, params)
        overlayView = root

        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        dragHandle.setOnTouchListener { _, event ->
            val p = overlayParams ?: return@setOnTouchListener false
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.rawX
                    downY = event.rawY
                    startX = p.x
                    startY = p.y
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    p.x = startX + (event.rawX - downX).toInt()
                    p.y = startY + (event.rawY - downY).toInt()
                    overlayView?.let { windowManager.updateViewLayout(it, p) }
                    true
                }
                else -> false
            }
        }
    }

    private fun showLookupResult() {
        val raw = lastOcrText
        if (raw.isBlank()) {
            resultTextView?.text = "먼저 OCR이 화면 텍스트를 읽을 때까지 잠시 기다리세요."
            return
        }
        val candidates = repo.findCandidates(raw, limit = 3)
        resultTextView?.text = if (candidates.isEmpty()) {
            "200단어장에서 일치 후보를 찾지 못했습니다."
        } else {
            candidates.joinToString("\n\n") { "${it.word}\n${it.meaning}" }
        }
    }

    private fun smallButton(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label
        textSize = 11f
        isAllCaps = false
        setPadding(dp(2), 0, dp(2), 0)
        setOnClickListener { onClick() }
    }

    private fun cleanupCapture(stopProjection: Boolean) {
        try { imageReader?.setOnImageAvailableListener(null, null) } catch (_: Throwable) {}
        try { virtualDisplay?.release() } catch (_: Throwable) {}
        try { imageReader?.close() } catch (_: Throwable) {}
        virtualDisplay = null
        imageReader = null

        val projection = mediaProjection
        val callback = projectionCallback
        if (projection != null && callback != null) {
            try { projection.unregisterCallback(callback) } catch (_: Throwable) {}
        }
        mediaProjection = null
        projectionCallback = null
        if (stopProjection) {
            try { projection?.stop() } catch (_: Throwable) {}
        }
    }

    override fun onDestroy() {
        cleanupCapture(stopProjection = true)
        try { latinRecognizer.close() } catch (_: Throwable) {}
        try { koreanRecognizer.close() } catch (_: Throwable) {}
        try { captureThread.quitSafely() } catch (_: Throwable) {}
        overlayView?.let {
            try { windowManager.removeView(it) } catch (_: Throwable) {}
        }
        overlayView = null
        if (Build.VERSION.SDK_INT >= 24) stopForeground(Service.STOP_FOREGROUND_REMOVE)
        else @Suppress("DEPRECATION") stopForeground(true)
        super.onDestroy()
    }

    private fun matchWrap() = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT,
        LinearLayout.LayoutParams.WRAP_CONTENT
    )

    private fun weightParam() = LinearLayout.LayoutParams(0, dp(44), 1f).apply {
        marginEnd = dp(3)
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
