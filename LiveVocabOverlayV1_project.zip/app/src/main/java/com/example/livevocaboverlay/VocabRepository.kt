package com.example.livevocaboverlay

import android.content.Context
import org.json.JSONArray
import kotlin.math.min


data class VocabEntry(
    val no: Int,
    val word: String,
    val meaning: String
)

class VocabRepository(context: Context) {

    val entries: List<VocabEntry>

    init {
        val json = context.assets.open("vocab.json").bufferedReader().use { it.readText() }
        val array = JSONArray(json)
        entries = (0 until array.length()).map { i ->
            val obj = array.getJSONObject(i)
            VocabEntry(
                no = obj.getInt("no"),
                word = obj.getString("word"),
                meaning = obj.getString("meaning")
            )
        }
    }

    fun findCandidates(rawText: String, limit: Int = 3): List<VocabEntry> {
        if (rawText.isBlank()) return emptyList()
        val normalizedRaw = normalize(rawText)
        val rawLines = rawText.lines().map(::normalizeLatin).filter { it.length >= 2 }
        val koreanTokens = hangulTokens(rawText)

        val scored = entries.mapNotNull { e ->
            var score = 0
            val wordNorm = normalize(e.word)
            val wordLatin = normalizeLatin(e.word)

            if (wordNorm.isNotBlank() && normalizedRaw.contains(wordNorm)) {
                score = maxOf(score, 2000 + wordNorm.length)
            }

            if (wordLatin.length >= 3) {
                for (line in rawLines) {
                    if (line == wordLatin) score = maxOf(score, 1900 + wordLatin.length)
                    else if (line.contains(wordLatin)) score = maxOf(score, 1700 + wordLatin.length)
                    else if (line.length in (wordLatin.length - 2)..(wordLatin.length + 2)) {
                        val d = levenshtein(line, wordLatin)
                        val tolerance = if (wordLatin.length <= 5) 1 else 2
                        if (d <= tolerance) score = maxOf(score, 1400 - d * 100 + wordLatin.length)
                    }
                }
            }

            if (koreanTokens.isNotEmpty()) {
                val entryTokens = hangulTokens(e.meaning)
                val common = koreanTokens.intersect(entryTokens)
                val tokenScore = common.sumOf { min(it.length, 6) }
                if (tokenScore >= 4) score = maxOf(score, 100 + tokenScore)
            }

            if (score > 0) e to score else null
        }

        return scored
            .sortedWith(compareByDescending<Pair<VocabEntry, Int>> { it.second }.thenBy { it.first.no })
            .map { it.first }
            .distinctBy { it.no }
            .take(limit)
    }

    private fun normalize(s: String): String =
        s.lowercase().replace(Regex("\\s+"), " ").trim()

    private fun normalizeLatin(s: String): String =
        s.lowercase()
            .replace(Regex("[^a-z ]"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()

    private fun hangulTokens(s: String): Set<String> {
        val stop = setOf("하다", "되다", "있는", "없는", "등을", "등의", "으로", "에서", "에게", "그리고", "또는")
        return Regex("[가-힣]{2,}")
            .findAll(s)
            .map { it.value }
            .filter { it !in stop }
            .toSet()
    }

    private fun levenshtein(a: String, b: String): Int {
        val prev = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            var diagonal = prev[0]
            prev[0] = i
            for (j in 1..b.length) {
                val old = prev[j]
                val cost = if (a[i - 1] == b[j - 1]) 0 else 1
                prev[j] = minOf(prev[j] + 1, prev[j - 1] + 1, diagonal + cost)
                diagonal = old
            }
        }
        return prev[b.length]
    }
}
