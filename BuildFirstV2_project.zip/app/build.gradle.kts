plugins {
    id("com.android.application")
}

android {
    namespace = "com.example.buildfirstv2"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.buildfirstv2"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
