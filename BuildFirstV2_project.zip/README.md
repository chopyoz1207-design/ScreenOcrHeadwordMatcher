# Build First V2

1단계 목표: 기능 추가 없이 APK 빌드와 설치만 확인.

성공 조건:
- GitHub Actions가 초록색 체크로 완료
- Artifact `BuildFirstV2-apk` 생성
- 압축을 풀면 `app-debug.apk`
- 휴대폰에 설치 후 앱 실행 시 `Build OK` 표시

이 단계가 성공하기 전에는 OCR/오버레이 기능을 추가하지 않습니다.
